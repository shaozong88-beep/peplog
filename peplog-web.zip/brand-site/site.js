(() => {
  const root = document.documentElement;
  const select = document.querySelector('#site-language');
  const menu = document.querySelector('.menu');
  const nav = document.querySelector('#navigation');
  let language = 'en';
  try { language = localStorage.getItem('peplog.website.language') === 'zh' ? 'zh' : 'en'; } catch {}
  const screenNames = { today: ['Today screen with example records', '今日看板示例记录'], library: ['Product library', '产品库'], calculator: ['Calculator with illustrative inputs', '计算器示例输入'], me: ['Personal tracking tools', '个人记录工具'] };
  function updateScreenAlt() {
    const image = document.querySelector('#feature-screen');
    const active = document.querySelector('[data-screen][aria-selected="true"]');
    if (image && active) image.alt = 'PepLog · ' + screenNames[active.dataset.screen][language === 'zh' ? 1 : 0];
  }
  function applyLanguage(code) {
    language = code === 'zh' ? 'zh' : 'en';
    root.lang = language === 'zh' ? 'zh-CN' : 'en';
    root.dataset.language = language;
    if (select) select.value = language;
    document.querySelectorAll('[data-en][data-zh]').forEach(el => { el.textContent = el.dataset[language]; });
    document.querySelectorAll('[data-label-en]').forEach(el => { el.setAttribute('aria-label', el.getAttribute(`data-label-${language}`)); });
    document.querySelectorAll('[data-title-en]').forEach(el => { document.title = el.getAttribute(`data-title-${language}`); });
    updateScreenAlt();
  }
  applyLanguage(language);
  select?.addEventListener('change', () => {
    applyLanguage(select.value);
    try { localStorage.setItem('peplog.website.language', language); } catch {}
  });
  function closeMenu() { nav?.classList.remove('open'); menu?.setAttribute('aria-expanded', 'false'); }
  menu?.addEventListener('click', () => {
    const open = menu.getAttribute('aria-expanded') !== 'true';
    menu.setAttribute('aria-expanded', String(open));
    nav?.classList.toggle('open', open);
  });
  nav?.addEventListener('click', event => { if (event.target.closest('a')) closeMenu(); });
  document.addEventListener('keydown', event => { if (event.key === 'Escape' && menu?.getAttribute('aria-expanded') === 'true') { closeMenu(); menu.focus(); } });
  const tabs = [...document.querySelectorAll('[data-screen]')];
  function activate(tab) {
    tabs.forEach(item => { item.setAttribute('aria-selected', String(item === tab)); item.tabIndex = item === tab ? 0 : -1; });
    document.querySelector('#feature-screen').src = `brand-site/${tab.dataset.screen}.webp`;
    document.querySelector('#feature-panel').setAttribute('aria-labelledby', tab.id);
    updateScreenAlt();
  }
  tabs.forEach((tab, index) => {
    tab.addEventListener('click', () => activate(tab));
    tab.addEventListener('keydown', event => {
      let target;
      if (['ArrowDown', 'ArrowRight'].includes(event.key)) target = (index + 1) % tabs.length;
      if (['ArrowUp', 'ArrowLeft'].includes(event.key)) target = (index + tabs.length - 1) % tabs.length;
      if (event.key === 'Home') target = 0;
      if (event.key === 'End') target = tabs.length - 1;
      if (target !== undefined) { event.preventDefault(); activate(tabs[target]); tabs[target].focus(); }
    });
  });
})();
